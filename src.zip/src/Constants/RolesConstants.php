<?php

namespace App\Constants;

class RolesConstants {
    public const ROLE_SUPERADMIN = 'ROLE_SUPERADMIN';
    public const ROLE_ADMIN = 'ROLE_ADMIN';
    public const ROLE_SPECIALIST = 'ROLE_SPECIALIST';
    public const ROLE_CLIENT = 'ROLE_CLIENT';
}

?>
